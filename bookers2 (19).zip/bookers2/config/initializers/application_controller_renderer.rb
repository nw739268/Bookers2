# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '6110e040ce1726ce7042199d4716207c3b9ce0085fca554bd9298534cc2ce3a63d6d8d4ff39377d12eb5e4de1525ff8c46b403d8f1827d7ae8afb5fdaff809ca'